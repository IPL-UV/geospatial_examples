### Admin 0 – Countries


<https://www.naturalearthdata.com/downloads/110m-cultural-vectors/110m-admin-0-countries/>
